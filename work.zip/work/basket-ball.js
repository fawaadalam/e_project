document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navCenter = document.querySelector('.nav-center');
    const searchContainer = document.querySelector('.search-container');
    const dropdownParents = document.querySelectorAll('.dropdown-parent');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navCenter.classList.toggle('active');
            searchContainer.classList.toggle('active');
            
            // Transform hamburger to X
            const spans = this.querySelectorAll('span');
            if (this.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    }
    
    // Handle dropdown menus on mobile
    dropdownParents.forEach(parent => {
        const link = parent.querySelector('a');
        
        link.addEventListener('click', function(e) {
            // Only prevent default and toggle dropdown on mobile
            if (window.innerWidth <= 992) {
                e.preventDefault();
                parent.classList.toggle('active');
                
                // Close other open dropdowns
                dropdownParents.forEach(otherParent => {
                    if (otherParent !== parent) {
                        otherParent.classList.remove('active');
                    }
                });
            }
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.navbar')) {
            if (mobileMenuToggle && mobileMenuToggle.classList.contains('active')) {
                mobileMenuToggle.click();
            }
        }
    });
    
    // Search functionality
    const searchBtn = document.querySelector('.search-btn');
    const searchInput = document.querySelector('.search-input');
    
    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', function() {
            searchproduct();
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchproduct();
            }
        });
    }
    
    // Card functionality
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        const button = card.querySelector('.card-button');
        const flipButton = card.querySelector('.flip-button');
        const progress = card.querySelector('.progress');
        const cardLink = card.dataset.link;
        
        if (button) {
            button.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent card link from activating
                card.classList.add('flipped');
            });
        }
        
        if (flipButton) {
            flipButton.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent card link from activating
                card.classList.remove('flipped');
            });
        }
        
        if (progress) {
            card.addEventListener('mouseover', function() {
                progress.style.width = '100%';
            });
            
            card.addEventListener('mouseout', function() {
                progress.style.width = '0';
            });
        }
        
        // Card link functionality
        card.addEventListener('click', function() {
            if (cardLink) {
                window.location.href = cardLink;
            }
        });
        
        // Prevent default link behavior for details link
        const detailsLink = card.querySelector('.details-link');
        if (detailsLink) {
            detailsLink.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent card link from activating
            });
        }
    });
    
    // Newsletter form
    const footerForm = document.getElementById('newsletter-form');
    
    if (footerForm) {
        footerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const button = this.querySelector('button');
            const input = this.querySelector('input');
            const originalText = button.textContent;
            
            // Disable the form during animation
            button.disabled = true;
            input.disabled = true;
            
            // Show loading state
            button.textContent = 'SENDING...';
            
            // Simulate form submission (would be replaced with actual API call)
            setTimeout(() => {
                button.textContent = 'THANK YOU!';
                button.style.backgroundColor = '#28a745';
                
                // Reset form after delay
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.backgroundColor = '';
                    button.disabled = false;
                    input.disabled = false;
                    input.value = '';
                }, 2000);
            }, 1000);
        });
    }
    
    // Add hover animation for footer links
    const footerLinks = document.querySelectorAll('.footer-section a');
    
    footerLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });
    
    // Intersection Observer for re-triggering footer animations when scrolling
    if ('IntersectionObserver' in window) {
        const footer = document.querySelector('.footer-container');
        
        if (footer) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        // Reset and replay animations
                        const animatedElements = footer.querySelectorAll('[style*="animation"]');
                        animatedElements.forEach(el => {
                            el.style.animation = 'none';
                            void el.offsetWidth; // Trigger reflow
                            el.style.animation = '';
                        });
                        
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            observer.observe(footer);
        }
    }
    
    // Responsive adjustments on window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 992) {
            // Reset mobile menu state on larger screens
            if (mobileMenuToggle && mobileMenuToggle.classList.contains('active')) {
                mobileMenuToggle.classList.remove('active');
                navCenter.classList.remove('active');
                searchContainer.classList.remove('active');
                
                // Reset hamburger icon
                const spans = mobileMenuToggle.querySelectorAll('span');
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
            
            // Reset dropdown states
            dropdownParents.forEach(parent => {
                parent.classList.remove('active');
            });
        }
    });
});

// Search product functionality
function searchproduct() {
    // Get the input value and convert to uppercase for case-insensitive comparison
    const input = document.getElementById("filter").value.toUpperCase();
    
    // Get all cards in the container
    const cards = document.querySelectorAll(".card");
    
    // Loop through all cards
    cards.forEach((card) => {
        // Get the title element from each card
        const title = card.querySelector(".card-title");
        
        // Check if the title contains the search input
        if (title && title.innerText.toUpperCase().indexOf(input) > -1) {
            // Show the card if it matches
            card.style.display = "";
        } else {
            // Hide the card if it doesn't match
            card.style.display = "none";
        }
    });
}