document.addEventListener("DOMContentLoaded", () => {
    // Mobile menu toggle
    const mobileToggle = document.querySelector(".mobile-toggle")
    const navCenter = document.querySelector(".nav-center")
    const searchContainer = document.querySelector(".search-container")
  
    if (mobileToggle) {
      mobileToggle.addEventListener("click", function () {
        this.classList.toggle("active")
        navCenter.classList.toggle("active")
        searchContainer.classList.toggle("active")
  
        // Transform hamburger to X
        const spans = this.querySelectorAll("span")
        if (this.classList.contains("active")) {
          spans[0].style.transform = "rotate(45deg) translate(5px, 5px)"
          spans[1].style.opacity = "0"
          spans[2].style.transform = "rotate(-45deg) translate(7px, -6px)"
        } else {
          spans[0].style.transform = "none"
          spans[1].style.opacity = "1"
          spans[2].style.transform = "none"
        }
      })
    }
  
    // Mobile dropdown toggle
    const dropdownContainers = document.querySelectorAll(".dropdown-container")
  
    dropdownContainers.forEach((container) => {
      const link = container.querySelector("a")
  
      // For mobile: add click event to toggle dropdown
      link.addEventListener("click", (e) => {
        if (window.innerWidth <= 992) {
          e.preventDefault()
          container.classList.toggle("active")
        }
      })
    })
  
    // Search functionality
    const searchBtn = document.querySelector(".search-btn")
    const searchInput = document.querySelector(".search-input")
  
    if (searchBtn && searchInput) {
      searchBtn.addEventListener("click", () => {
        if (searchInput.value.trim() !== "") {
          alert("Searching for: " + searchInput.value)
          searchInput.value = ""
        }
      })
  
      searchInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          searchBtn.click()
        }
      })
    }
  
    // Animation on scroll
    const animatedElements = document.querySelectorAll("[data-aos]")
  
    function checkScroll() {
      animatedElements.forEach((element) => {
        const elementPosition = element.getBoundingClientRect().top
        const windowHeight = window.innerHeight
  
        if (elementPosition < windowHeight * 0.8) {
          const delay = element.getAttribute("data-aos-delay") || 0
          setTimeout(() => {
            element.style.opacity = "1"
            element.style.transform = "translateY(0)"
          }, delay)
        }
      })
    }
  
    // Initial check and scroll event
    checkScroll()
    window.addEventListener("scroll", checkScroll)
  
    // Form validation
    const contactForm = document.getElementById("contact-form")
  
    if (contactForm) {
      contactForm.addEventListener("submit", (e) => {
        e.preventDefault()
  
        // Reset previous error messages
        const errorMessages = document.querySelectorAll(".error-message")
        errorMessages.forEach((msg) => msg.remove())
  
        const inputs = contactForm.querySelectorAll("input, textarea")
        inputs.forEach((input) => input.classList.remove("error"))
  
        // Validate each field
        let isValid = true
  
        const name = document.getElementById("name")
        const email = document.getElementById("email")
        const phone = document.getElementById("phone")
        const message = document.getElementById("message")
  
        // Name validation
        if (name.value.trim() === "") {
          showError(name, "Name is required")
          isValid = false
        }
  
        // Email validation
        if (email.value.trim() === "") {
          showError(email, "Email is required")
          isValid = false
        } else if (!isValidEmail(email.value)) {
          showError(email, "Please enter a valid email address")
          isValid = false
        }
  
        // Phone validation
        if (phone.value.trim() === "") {
          showError(phone, "Phone number is required")
          isValid = false
        } else if (!isValidPhone(phone.value)) {
          showError(phone, "Please enter a valid phone number")
          isValid = false
        }
  
        // Message validation
        if (message.value.trim() === "") {
          showError(message, "Message is required")
          isValid = false
        }
  
        // If form is valid, submit or show success message
        if (isValid) {
          showSuccessMessage()
          contactForm.reset()
        }
      })
    }
  
    // Helper functions for validation
    function showError(input, message) {
      input.classList.add("error")
      const errorDiv = document.createElement("div")
      errorDiv.className = "error-message"
      errorDiv.innerText = message
  
      // Insert error message after the input
      input.parentNode.insertBefore(errorDiv, input.nextSibling)
    }
  
    function isValidEmail(email) {
      const re =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
      return re.test(String(email).toLowerCase())
    }
  
    function isValidPhone(phone) {
      // Basic phone validation - can be adjusted based on requirements
      const re = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/
      return re.test(String(phone))
    }
  
    function showSuccessMessage() {
      // Remove any existing success message
      const existingMessage = document.querySelector(".success-message")
      if (existingMessage) {
        existingMessage.remove()
      }
  
      // Create and show new success message
      const successDiv = document.createElement("div")
      successDiv.className = "success-message"
      successDiv.innerText = "Your message has been sent successfully! We will get back to you soon."
  
      contactForm.parentNode.insertBefore(successDiv, contactForm.nextSibling)
      successDiv.style.display = "block"
  
      // Scroll to success message
      successDiv.scrollIntoView({ behavior: "smooth", block: "center" })
  
      // Hide success message after 5 seconds
      setTimeout(() => {
        successDiv.style.opacity = "0"
        setTimeout(() => {
          successDiv.remove()
        }, 500)
      }, 5000)
    }
  
    // Add hover effects for info cards
    const infoCards = document.querySelectorAll(".info-card")
    infoCards.forEach((card) => {
      card.addEventListener("mouseenter", function () {
        this.style.transform = "translateY(-5px)"
        this.style.boxShadow = "0 10px 20px rgba(0, 0, 0, 0.05)"
      })
  
      card.addEventListener("mouseleave", function () {
        this.style.transform = "translateY(0)"
        this.style.boxShadow = "none"
      })
    })
  
    // Newsletter form submission
    const newsletterForm = document.getElementById("newsletter-form")
  
    if (newsletterForm) {
      newsletterForm.addEventListener("submit", function (e) {
        e.preventDefault()
  
        const button = this.querySelector("button")
        const input = this.querySelector("input")
        const originalText = button.textContent
  
        // Disable the form during animation
        button.disabled = true
        input.disabled = true
  
        // Show loading state
        button.textContent = "SENDING..."
  
        // Simulate form submission (would be replaced with actual API call)
        setTimeout(() => {
          button.textContent = "THANK YOU!"
          button.style.backgroundColor = "#28a745"
  
          // Reset form after delay
          setTimeout(() => {
            button.textContent = originalText
            button.style.backgroundColor = ""
            button.disabled = false
            input.disabled = false
            input.value = ""
          }, 2000)
        }, 1000)
      })
    }
  
    // Intersection Observer for re-triggering animations when scrolling
    if ("IntersectionObserver" in window) {
      const footer = document.querySelector(".footer-container")
  
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              // Reset and replay animations
              const animatedElements = footer.querySelectorAll('[style*="animation"]')
              animatedElements.forEach((el) => {
                el.style.animation = "none"
                void el.offsetWidth // Trigger reflow
                el.style.animation = ""
              })
  
              observer.unobserve(entry.target)
            }
          })
        },
        { threshold: 0.1 },
      )
  
      observer.observe(footer)
    }
  })
  
  